# MBTI
my-friends  MBTI dictionary
